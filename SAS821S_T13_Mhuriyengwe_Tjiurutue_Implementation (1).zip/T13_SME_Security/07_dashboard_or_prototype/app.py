"""
app.py — Analyst Triage Dashboard (C10: decision-support prototype)
---------------------------------------------------------------------
Run with:  streamlit run app.py
Ties together every analytical layer (C1-C9) into one explainable,
analyst-facing view answering the core decision:
"Given today's alerts, tickets and findings across all clients, which
should the analyst investigate first, and why?"
"""

import streamlit as st
import pandas as pd
import json
import time
import matplotlib.pyplot as plt
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent  # T13_SME_Security/
PROC = str(ROOT / "02_data" / "processed")
OUT = str(ROOT / "08_outputs")

sys.path.insert(0, str(ROOT / "03_notebooks_or_scripts"))
from live_capture_lib import capture_one_event, append_to_log, load_models
import numpy as np

st.set_page_config(page_title="T13 · SME Triage Dashboard", layout="wide", page_icon="🛡️")

@st.cache_data
def load_data():
    alerts = pd.read_csv(f"{PROC}/alerts_scored.csv", parse_dates=["timestamp"])
    tickets = pd.read_csv(f"{PROC}/tickets_scored.csv", parse_dates=["timestamp"])
    clients = pd.read_csv(f"{PROC}/clients_clean.csv")
    exec_digest = pd.read_csv(f"{OUT}/executive_risk_digest.csv")
    incident_timeline = pd.read_csv(f"{OUT}/incident_timeline.csv")
    forecast = pd.read_csv(f"{OUT}/predictive_risk_forecast.csv")
    sim_summary = pd.read_csv(f"{OUT}/simulation_summary.csv")
    sim_sens = pd.read_csv(f"{OUT}/simulation_sensitivity.csv")
    with open(f"{OUT}/adversarial_test_results.json") as f:
        adversarial = json.load(f)
    with open(f"{OUT}/supervised_metrics.json") as f:
        sup_metrics = json.load(f)
    with open(f"{OUT}/text_mining_metrics.json") as f:
        text_metrics = json.load(f)
    return alerts, tickets, clients, exec_digest, incident_timeline, forecast, sim_summary, sim_sens, adversarial, sup_metrics, text_metrics

(alerts, tickets, clients, exec_digest, incident_timeline, forecast,
 sim_summary, sim_sens, adversarial, sup_metrics, text_metrics) = load_data()

st.title("🛡️ SME Managed Security Monitoring — Analyst Triage Dashboard")
st.caption("T13 · Explainable alert prioritisation across multiple SME clients | "
           "Prototype by Mhuriyengwe & Tjiurutue · SAS821S Capstone")

# ---------------------------------------------------------------------------
# Sidebar filters
# ---------------------------------------------------------------------------
st.sidebar.header("Filters")
client_options = ["All clients"] + sorted(clients["client_id"].tolist())
selected_client = st.sidebar.selectbox("Client", client_options)
min_prob = st.sidebar.slider("Minimum risk score to display", 0.0, 1.0, 0.0, 0.05)
st.sidebar.markdown("---")
st.sidebar.markdown("**Client directory**")
st.sidebar.dataframe(clients[["client_id","name","size"]], hide_index=True, use_container_width=True)

def filt(df, client_col="client_id"):
    if selected_client != "All clients":
        return df[df[client_col] == selected_client]
    return df

# ---------------------------------------------------------------------------
# Top-level KPIs
# ---------------------------------------------------------------------------
kpi1, kpi2, kpi3, kpi4 = st.columns(4)
f_alerts = filt(alerts)
kpi1.metric("Total alerts (30d)", f"{len(f_alerts):,}")
kpi2.metric("Predicted true-positive rate", f"{(f_alerts['tp_probability']>0.5).mean()*100:.1f}%")
kpi3.metric("Open incidents flagged", f"{len(filt(incident_timeline))}")
kpi4.metric("Clients monitored", f"{clients['client_id'].nunique()}")

tab1, tab2, tab3, tab4, tab5, tab6, tab7 = st.tabs([
    "🚨 Priority Queue", "📊 Executive Risk Digest", "🕒 Incident Timeline",
    "📝 Ticket Intelligence", "🔮 Predictive & Adversarial", "⚖️ Triage Strategy Simulation",
    "🔴 Live Capture"
])

# ---------------------------------------------------------------------------
# TAB 1: Priority Queue (the core decision)
# ---------------------------------------------------------------------------
with tab1:
    st.subheader("Which alerts should be investigated first, and why?")
    queue = filt(alerts)
    queue = queue[queue["tp_probability"] >= min_prob].sort_values("tp_probability", ascending=False).head(50)

    def explain(row):
        reasons = []
        if row["severity"] == "high": reasons.append("high severity")
        if row["off_hours"]: reasons.append("off-hours activity")
        if row["tp_probability"] > 0.7: reasons.append("strong model confidence")
        return ", ".join(reasons) if reasons else "baseline risk factors"

    queue_display = queue.copy()
    queue_display["explanation"] = queue_display.apply(explain, axis=1)
    queue_display["risk_score"] = (queue_display["tp_probability"] * 100).round(1)
    st.dataframe(
        queue_display[["client_id","timestamp","description","severity","mitre_tag","risk_score","explanation"]]
        .rename(columns={"risk_score":"Risk score (%)"}),
        use_container_width=True, hide_index=True, height=500
    )
    st.caption("Risk score = supervised classifier's predicted probability the alert is a true positive. "
               "Explanation lists the main contributing factors for analyst context (explainability requirement).")

# ---------------------------------------------------------------------------
# TAB 2: Executive Risk Digest
# ---------------------------------------------------------------------------
with tab2:
    st.subheader("Per-client risk summary (executive audience)")
    st.dataframe(
        exec_digest.sort_values("composite_risk_score", ascending=False),
        use_container_width=True, hide_index=True
    )
    col1, col2 = st.columns(2)
    with col1:
        st.image(f"{OUT}/baseline_alerts_per_client.png", caption="Alert volume per client")
    with col2:
        st.image(f"{OUT}/baseline_severity_mix.png", caption="Severity mix per client")

# ---------------------------------------------------------------------------
# TAB 3: Incident Timeline
# ---------------------------------------------------------------------------
with tab3:
    st.subheader("Correlated incident timeline")
    st.caption("Client-days where the unsupervised anomaly detector flagged unusual behaviour, "
               "correlated with high-risk alerts, anomalous logins and open vulnerabilities.")
    tl = filt(incident_timeline)
    if len(tl) == 0:
        st.info("No correlated incidents for this filter.")
    else:
        for _, row in tl.sort_values("anomaly_score", ascending=False).head(15).iterrows():
            with st.expander(f"{row['client_id']} · {row['date']} · anomaly score {row['anomaly_score']:.2f} · {row['likely_category']}"):
                c1, c2 = st.columns(2)
                c1.write(f"**High-risk alerts:** {row['n_high_risk_alerts']}")
                c1.write(f"**Anomalous logins:** {row['n_anomalous_logins']}")
                c1.write(f"**Open vulnerabilities on client:** {row['n_open_vulns_on_client']}")
                c2.write(f"**Related tickets:** {row['n_related_tickets']}")
                c2.write(f"**Recommended response:** {row['recommended_response']}")
                st.write(f"**Affected entities (sample):** {row['affected_entities_sample']}")

# ---------------------------------------------------------------------------
# TAB 4: Ticket / Text Mining Intelligence
# ---------------------------------------------------------------------------
with tab4:
    st.subheader("Ticket text mining")
    c1, c2, c3 = st.columns(3)
    c1.metric("Category classifier macro-F1", text_metrics["category_macro_f1"])
    c2.metric("Urgency classifier macro-F1", text_metrics["urgency_macro_f1"])
    c3.metric("Tickets with extracted entities", text_metrics["n_with_extracted_entities"])
    st.warning("Note: near-perfect text classification metrics reflect the templated nature of the "
               "synthetic ticket data, not a claim of real-world performance - see documented limitations.")
    st.image(f"{OUT}/text_category_distribution.png")
    tk = filt(tickets)
    st.dataframe(
        tk[["ticket_id","client_id","timestamp","description","predicted_category","predicted_urgency"]],
        use_container_width=True, hide_index=True, height=350
    )

# ---------------------------------------------------------------------------
# TAB 5: Predictive & Adversarial
# ---------------------------------------------------------------------------
with tab5:
    st.subheader("Predictive early-warning (per client)")
    st.dataframe(forecast, use_container_width=True, hide_index=True)
    st.caption("Forecast = rolling 3-day anomaly trend projected forward. Flagged clients show a rising "
               "trend beyond their own 75th-percentile historical anomaly level.")

    st.subheader("Adversarial / robustness test results")
    t1, t2, t3 = st.columns(3)
    with t1:
        st.markdown("**Test 1: Alert flooding**")
        st.json(adversarial["test_1_alert_flooding"]["results"])
        st.caption(adversarial["test_1_alert_flooding"]["description"])
    with t2:
        st.markdown("**Test 2: Slow/evasive attack**")
        st.json(adversarial["test_2_slow_evasive_attack"]["results"])
        st.caption(adversarial["test_2_slow_evasive_attack"]["description"])
    with t3:
        st.markdown("**Test 3: Label poisoning**")
        st.json(adversarial["test_3_label_poisoning"]["results"])
        st.caption(adversarial["test_3_label_poisoning"]["description"])
    st.image(f"{OUT}/adversarial_poisoning_chart.png")

# ---------------------------------------------------------------------------
# TAB 6: Simulation
# ---------------------------------------------------------------------------
with tab6:
    st.subheader("Triage strategy comparison (Monte Carlo simulation)")
    st.dataframe(sim_summary, use_container_width=True, hide_index=True)
    st.image(f"{OUT}/simulation_comparison_chart.png")
    st.caption("Compares manual/FIFO triage, risk-scored triage, and risk-scored triage with "
               "auto-suppression of low-risk alerts, across randomised simulated shifts.")

# ---------------------------------------------------------------------------
# TAB 7: Live Capture (simulated real-time feed, scored by the trained models)
# ---------------------------------------------------------------------------
with tab7:
    st.subheader("How new events get captured and categorised in real time")
    st.caption(
        "This simulates events arriving one at a time — not a real network feed — and runs each one "
        "through the SAME trained models used everywhere else in this dashboard (the supervised "
        "TP/FP classifier and the text-mining category/urgency classifier). It shows the ingestion "
        "step the batch pipeline already performs, just live and one event at a time."
    )

    live_models = load_models()
    if live_models["clf"] is None:
        st.warning("No trained classifier found in 04_models/ — run 03_ml_models.py first, then reload this page.")

    colA, colB, colC = st.columns([1, 1, 2])
    n_events = colA.slider("Events to capture", 5, 50, 15)
    speed = colB.slider("Seconds between events", 0.1, 2.0, 0.4)
    start = colC.button("▶ Start live capture", type="primary")

    if start:
        rng = np.random.default_rng()
        placeholder_table = st.empty()
        placeholder_metrics = st.empty()
        captured = []
        tier_counts = {"🔴 HIGH": 0, "🟡 MEDIUM": 0, "🟢 LOW": 0}
        ticket_count = 0

        for i in range(n_events):
            event = capture_one_event(rng, live_models)
            append_to_log(event)
            captured.append(event)

            if event["event_type"] == "alert":
                tier_counts[event["priority_tier"]] = tier_counts.get(event["priority_tier"], 0) + 1
            else:
                ticket_count += 1

            m1, m2, m3, m4 = placeholder_metrics.columns(4)
            m1.metric("🔴 High", tier_counts["🔴 HIGH"])
            m2.metric("🟡 Medium", tier_counts["🟡 MEDIUM"])
            m3.metric("🟢 Low", tier_counts["🟢 LOW"])
            m4.metric("🎫 Tickets", ticket_count)

            display_df = pd.DataFrame(captured).iloc[::-1]  # newest first
            show_cols = [c for c in ["captured_at", "event_type", "client_id", "description",
                                      "tp_probability", "priority_tier",
                                      "predicted_category", "predicted_urgency"] if c in display_df.columns]
            placeholder_table.dataframe(display_df[show_cols], use_container_width=True, hide_index=True)

            time.sleep(speed)

        st.success(f"Captured and scored {n_events} live events. Full log: 08_outputs/live_captured_events.csv")

    st.markdown("---")
    st.caption(
        "Scope note: the unsupervised per-client anomaly detector (Tab-independent, used in the batch "
        "pipeline) operates on *daily aggregates*, not single events, so it isn't meaningfully re-run "
        "per live event here — what's genuinely live in this tab is the supervised risk score and the "
        "text-mining classifier, exactly as a production ingestion pipeline would use them."
    )

st.markdown("---")
st.caption("SAS821S Security Analytics Capstone · Topic T13 · Milestone 2 prototype")
