# Known defects and implementation backlog

SAS821S · T13 · Milestone 2 (Project Implementation Plan and Working Prototype)
Group: Mhuriyengwe (223027138) & Tjiurutue (220097615)

## Known defects / limitations (honest, for Milestone 3 discussion)

| # | Issue | Severity | Where it shows up |
|---|---|---|---|
| 1 | Supervised alert classifier accuracy (~64%) is modest | Low — expected | Reflects genuine label noise built into data generation (each rule has an inherent FP rate); not a bug, but should be framed honestly in the final report rather than oversold |
| 2 | Text-mining classifiers score near-perfect (F1 ≈ 1.00) | Medium | Artefact of templated synthetic ticket generation — real-world tickets are far messier. Flagged in-app (dashboard shows a warning banner) and in the README |
| 3 | Slow/evasive attacks evade the per-client anomaly detector | Medium — genuine finding | Adversarial Test 2 shows detection drops from 100% to ~10–27% as the same attack is spread across more days. This is a real limitation of volume-based daily anomaly detection worth turning into a governance recommendation |
| 4 | Simulation assumes constant 6-minute review time per alert | Low | Doesn't model analyst fatigue, interruptions, or partial reviews — documented in `simulation_assumptions.json` |
| 5 | Composite risk score uses fixed weights (0.5/0.3/0.2) | Low | Not learned or validated against outcomes; reasonable for a prototype but should be flagged as a simplification in Milestone 3 |
| 6 | Only 7 simulated clients | Low | Limits statistical power of per-client baselining; acceptable per Charter's approved scope but worth naming as a limitation |
| 7 | Reference SIEM instance not yet stood up | Open | Charter's hybrid design calls for a lightweight real Wazuh (or similar) instance for schema validation/screenshots — not required for core marks, but still on the to-do list before Milestone 3 |
| 8 | Automation hook (Shuffle-style notification) not implemented | Open — stretch goal | Explicitly scoped as optional in the Charter; architecture diagram shows it as a future integration point only |

## Implementation backlog (before Milestone 3, 25 Sept)

**Must do:**
- [ ] Stand up the lightweight reference SIEM instance and capture 2–3 real screenshots for the final report
- [ ] Write up all documented limitations above into the final report's "Limitations" section
- [ ] Add per-member contribution statement (signed) per Section 9.1
- [ ] Expand README with a short "how to interpret the dashboard" section for non-technical readers (useful for the Milestone 4 demo too)

**Should do:**
- [ ] Add 1–2 more adversarial tests if time allows (e.g. adversarial evasion via severity-score manipulation)
- [ ] Sensitivity-test the composite risk score weights (0.5/0.3/0.2) to show the ranking is reasonably stable
- [ ] Add basic input validation to the dashboard filters (currently assumes well-formed data, which is fine for the prototype but worth noting as a hardening step for production)

**Could do (stretch, only if ahead of schedule):**
- [ ] Implement one real Shuffle (or equivalent) notification workflow as a proof-of-concept
- [ ] Add a simple auth check in front of the Streamlit app to acknowledge production access-control needs

## Test coverage

39 automated checks in `tests/test_pipeline.py`, covering:
- Data integrity (record minimums, referential integrity, null checks, range checks)
- Model output sanity (metric bounds, beats-naive-baseline checks)
- Text-mining output completeness
- Investigation/intelligence output correctness (ranking order, tier validity)
- Simulation (iteration count, strategy comparison direction)
- Predictive/adversarial (minimum test count, monotonic degradation under poisoning)
- Dashboard dependency existence and app syntax validity

Run with: `pytest tests/ -v` (39/39 passing as of last full pipeline run).
