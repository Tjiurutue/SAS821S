# Partner Briefing — T13 Prototype Walkthrough & GitHub Submission

For: Tjiurutue (220097615), from Mhuriyengwe (223027138)
Purpose: explain how the working prototype works, how we submit it on GitHub,
and exactly how it satisfies the Milestone 2 marking rubric.

---

## 1. How the code works — the pipeline, step by step

Everything lives under `T13_SME_Security/`. The core idea: **one decision drives
everything** — *given today's alerts, tickets and findings across all clients,
which should the analyst investigate first, and why?* Every script below feeds
that single decision.

Run order (each script reads the previous one's output):

| # | Script | What it does | Produces |
|---|---|---|---|
| 1 | `01_generate_data.py` | Generates our synthetic MSSP data: 7 fake client companies, alerts, vuln scans, auth logs, tickets | Raw CSVs in `02_data/raw/` |
| 2 | `02_ingest_and_baseline.py` | Cleans the data, checks for nulls/duplicates/bad IDs, writes a data dictionary, makes baseline charts | Cleaned CSVs, charts, `data_dictionary.json` |
| 3 | `03_ml_models.py` | Trains the **supervised** model (is this alert a real incident or a false positive?) and the **unsupervised** model (does this client's alert pattern today look abnormal?) | Trained models, confusion matrix, anomaly scores |
| 4 | `04_text_mining.py` | Reads ticket free-text, predicts category (malware/phishing/access/etc.) and urgency, pulls out asset codes | Scored tickets |
| 5 | `05_investigation_intelligence.py` | Links alerts + auth logs + vuln findings into incident timelines per client; builds the ranked "priority queue" and the per-client "executive risk digest" | Timeline, priority queue, risk digest |
| 6 | `06_simulation.py` | Runs 1,500 simulated shifts comparing 3 triage strategies (manual FIFO vs. risk-scored vs. risk-scored-with-suppression) | Simulation results |
| 7 | `07_predictive_adversarial.py` | Forecasts which client is likely to escalate next; stress-tests the model against 3 attack types (alert flooding, slow/evasive attacks, poisoned training labels) | Forecast, adversarial test results |
| — | `07_dashboard_or_prototype/app.py` | The Streamlit dashboard — pulls together everything above into one interactive, explainable view | The actual working prototype |

**In plain terms:** scripts 1–2 build and clean the data. Script 3 is the
"is this alert real?" brain. Script 4 reads the human-written tickets. Script
5 turns all of that into a ranked to-do list. Scripts 6–7 prove the approach
actually helps and stress-test it. The dashboard is the thing a marker (or a
real analyst) actually clicks through.

**To run it yourself, in order:**
```bash
cd T13_SME_Security
python -m pip install -r requirements.txt
cd 03_notebooks_or_scripts
python 01_generate_data.py
python 02_ingest_and_baseline.py
python 03_ml_models.py
python 04_text_mining.py
python 05_investigation_intelligence.py
python 06_simulation.py
python 07_predictive_adversarial.py
cd ..
python -m streamlit run 07_dashboard_or_prototype/app.py
```
(You already have all the generated outputs in the zip, so you don't strictly
need to re-run 1–7 unless you change something — just launching the dashboard
is enough to see it working.)

To check nothing is broken after a change:
```bash
python -m pytest tests/ -v
```
39 automated checks — if these all pass, the pipeline and dashboard are
internally consistent.

---

## 2. Getting this onto GitHub properly

The brief (Section 11) recommends a GitHub repo, and Section 4.2 explicitly
requires **version-control commits as contribution evidence** for both
members. A repo with only one person's commits is a risk — the Facilitator
can adjust individual marks if contribution looks unbalanced (Section 4.2).

### One-time setup (whoever does this first)
```bash
cd T13_SME_Security
git init
git add .
git commit -m "Initial working prototype: full pipeline + dashboard (C1-C10)"
```
Create a **private** repo on GitHub (call it something like
`SAS821S-T13-SME-Security`), then:
```bash
git remote add origin https://github.com/<username>/SAS821S-T13-SME-Security.git
git branch -M main
git push -u origin main
```
Then add the other person as a **collaborator**: GitHub repo → Settings →
Collaborators → add by username.

### From then on — both of us need real commits
This matters for the mark, not just tidiness. Suggested split, matching the
Charter's RACI table:

- **Mhuriyengwe:** commits touching data generation, ML models, feature
  engineering, predictive/adversarial testing
- **Tjiurutue:** commits touching investigation/timeline logic, intelligence
  outputs, simulation, dashboard/UI polish

Practical workflow:
```bash
git pull                          # get the other person's latest changes first
# ... make your changes ...
git add <files you changed>
git commit -m "Short, specific message about what changed and why"
git push
```

A few real, easy things Tjiurutue could commit right now so the history isn't
one-sided from the start:
- Review the dashboard tabs and tweak labels/wording where something's unclear
- Add a couple more rows to the RULE_CATALOGUE or TICKET_TEMPLATES in
  `01_generate_data.py` (more variety = more realistic data)
- Write the signed contribution statement and commit it into `09_documentation/`

### What to include / exclude
Add a `.gitignore` with:
```
__pycache__/
.pytest_cache/
*.pyc
.DS_Store
```
Everything else — including the generated CSVs and trained model files —
should be committed, since the brief's reproducibility bundle (Section 9.2)
expects outputs to be inspectable, not just regeneratable.

---

## 3. How this satisfies the Milestone 2 rubric (40%, due 20 Sept)

| Rubric criterion (marks) | Where it's covered |
|---|---|
| Architecture and data pipeline (6) | Scripts 1–2; `README.md`; architecture diagrams |
| Baseline and exploratory analytics (5) | Script 2 — 3 baseline charts + descriptive stats per client |
| Machine-learning and anomaly methods (8) | Script 3 — supervised classifier + unsupervised anomaly detector, both evaluated honestly |
| Investigation, access analytics and intelligence (6) | Script 5 — timelines, priority queue, executive digest; auth-log anomaly detection covers access analytics |
| Simulation, text mining and predictive/adversarial design (8) | Scripts 4, 6, 7 |
| Working prototype, testing and repository evidence (5) | `07_dashboard_or_prototype/app.py`, `tests/` (39 passing), GitHub repo itself |
| Implementation management and team evidence (2) | RACI table in Charter + real commit history from both of us |

Every C1–C10 requirement from Section 5 of the brief has working, tested code
behind it — not just a plan. `09_documentation/known_defects_and_backlog.md`
already lists the honest limitations (e.g. the model struggles to detect
slow/spread-out attacks) which is exactly the kind of finding Milestone 3
rewards when written up properly.

---

*Generated with Claude's assistance per Section 13 disclosure requirements —
reviewed and to be restated in our own words for the final submission.*
