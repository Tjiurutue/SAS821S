"""
07_predictive_adversarial.py
------------------------------
C9: Predictive and adversarial analysis.

Predictive: a forward-looking per-client risk forecast for "tomorrow",
            based on a rolling trend of the last N days' anomaly scores and
            alert volume (early-warning signal, not just a snapshot).

Adversarial / robustness tests (>=3):
  1. Alert-flooding evasion: attacker sends many low-severity/benign-looking
     alerts to bury a real high-risk alert - does mean risk score / ranking
     position of the real alert degrade?
  2. Slow/evasive attack: attacker spreads a real attack's alerts thinly
     across many days (low daily volume) - does the per-client anomaly
     detector still catch it, or does it hide below the anomaly threshold?
  3. Label-poisoning: if an attacker/insider mislabels a fraction of
     training alerts (TP relabelled as FP), how much does supervised model
     performance (F1) degrade?
"""

import pandas as pd
import numpy as np
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score
from sklearn.preprocessing import LabelEncoder

from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent  # T13_SME_Security/
PROC = str(ROOT / "02_data" / "processed")
OUT = str(ROOT / "08_outputs")
SEED = 821
rng = np.random.default_rng(SEED)

alerts = pd.read_csv(f"{PROC}/alerts_scored.csv", parse_dates=["timestamp"])
client_anom = pd.read_csv(f"{PROC}/client_anomaly_scored.csv", parse_dates=["date"])

# ---------------------------------------------------------------------------
# PREDICTIVE: rolling risk forecast per client
# ---------------------------------------------------------------------------
forecast_rows = []
for cid, grp in client_anom.groupby("client_id"):
    grp = grp.sort_values("date")
    grp["rolling_anomaly_3d"] = grp["anomaly_score"].rolling(3, min_periods=1).mean()
    grp["trend"] = grp["rolling_anomaly_3d"].diff()
    last = grp.iloc[-1]
    # Simple forecast: last rolling value + trend. NOT floored at zero - the
    # anomaly score is signed (negative = more normal than average, positive
    # = more anomalous than average), so negative forecasts are meaningful.
    trend_val = last["trend"] if not np.isnan(last["trend"]) else 0
    forecast_next = last["rolling_anomaly_3d"] + trend_val
    forecast_rows.append({
        "client_id": cid,
        "last_rolling_anomaly_score": round(last["rolling_anomaly_3d"], 3),
        "recent_trend": round(trend_val, 3),
        "forecast_next_day_risk": round(forecast_next, 3),
        "early_warning_flag": bool(forecast_next > grp["anomaly_score"].quantile(0.75)),
    })
forecast_df = pd.DataFrame(forecast_rows).sort_values("forecast_next_day_risk", ascending=False)
forecast_df.to_csv(f"{OUT}/predictive_risk_forecast.csv", index=False)
print("=== C9: Predictive per-client risk forecast ===")
print(forecast_df.to_string(index=False))

# ---------------------------------------------------------------------------
# Rebuild the supervised pipeline components needed for adversarial tests
# ---------------------------------------------------------------------------
alerts["hour"] = alerts["timestamp"].dt.hour
alerts["dayofweek"] = alerts["timestamp"].dt.dayofweek
le_rule, le_mitre, le_client = LabelEncoder(), LabelEncoder(), LabelEncoder()
alerts["rule_enc"] = le_rule.fit_transform(alerts["rule_id"])
alerts["mitre_enc"] = le_mitre.fit_transform(alerts["mitre_tag"])
alerts["client_enc"] = le_client.fit_transform(alerts["client_id"])
alerts["off_hours_int"] = alerts["off_hours"].astype(int)
FEATURES = ["severity_score", "rule_enc", "mitre_enc", "client_enc", "hour", "dayofweek", "off_hours_int"]
X = alerts[FEATURES]
y = (alerts["label"] == "TP").astype(int)

adversarial_results = {}

# --- Test 1: Alert-flooding evasion ---------------------------------------
# Pick one genuine high-risk alert; simulate flooding its client-day with
# many low-severity noise alerts; check whether its RANK within that day's
# queue degrades.
clf_base = RandomForestClassifier(n_estimators=300, max_depth=10, random_state=SEED, class_weight="balanced")
clf_base.fit(X, y)
alerts["tp_probability"] = clf_base.predict_proba(X)[:, 1]

target = alerts[(alerts["label"] == "TP") & (alerts["severity"] == "high")].sample(1, random_state=SEED).iloc[0]
same_day = alerts[(alerts["client_id"] == target["client_id"]) &
                   (alerts["timestamp"].dt.date == target["timestamp"].date())]
baseline_rank = (same_day["tp_probability"] > target["tp_probability"]).sum() + 1
baseline_size = len(same_day)

flood_ranks = []
# Use a MODERATE-severity, high-FP-rate rule for the flood (R1003, high sev but
# fp_rate 0.35) rather than a trivially low-severity one - a realistic attacker
# trying to bury a real alert would pick noisy-but-plausible-looking alerts,
# not obviously benign ones.
for n_flood in [0, 20, 50, 100, 200]:
    flood_rows = pd.DataFrame([{
        "severity_score": 3, "rule_enc": le_rule.transform(["R1003"])[0],
        "mitre_enc": le_mitre.transform(["T1204 User Execution"])[0],
        "client_enc": le_client.transform([target["client_id"]])[0],
        "hour": target["hour"], "dayofweek": target["dayofweek"], "off_hours_int": 0,
    }] * n_flood)
    combined = pd.concat([same_day[FEATURES], flood_rows], ignore_index=True)
    probs = clf_base.predict_proba(combined)[:, 1]
    target_prob = target["tp_probability"]
    rank = (probs > target_prob).sum() + 1
    flood_ranks.append({"n_flood_alerts_injected": n_flood, "target_alert_rank": int(rank), "queue_size": len(combined)})

adversarial_results["test_1_alert_flooding"] = {
    "description": "Injecting low-severity 'noise' alerts on the same client-day as a genuine high-risk alert, "
                    "checking whether the model's risk-ranking still surfaces it near the top.",
    "target_alert_id": target["alert_id"],
    "results": flood_ranks,
}
print("\n=== Adversarial Test 1: Alert Flooding ===")
for r in flood_ranks:
    print(r)

# --- Test 2: Slow / evasive attack -----------------------------------------
# Take a genuine attack pattern (multiple related high-risk alerts for one
# client) and check detection when compressed into 1 day vs spread over 10.
cid_test = alerts["client_id"].value_counts().idxmax()
attack_alert_template = alerts[(alerts["rule_id"] == "R1002") & (alerts["client_id"] == cid_test)].iloc[0]

def build_blended_attack_days(n_attack_events, spread_days, normal_days_df):
    # Realistic model: the attacker's alerts land ON TOP OF that day's normal
    # background traffic, not in isolation. We sample a real normal day's
    # profile for each day in the spread window, then blend in the attack
    # contribution (severity 3, some off-hours activity) proportionally.
    events_per_day = n_attack_events / spread_days
    blended = []
    for _ in range(spread_days):
        base_day = normal_days_df.sample(1, random_state=int(rng.integers(0,1_000_000))).iloc[0]
        n_normal, sev_normal, offh_normal = base_day["n_alerts"], base_day["mean_severity"], base_day["pct_off_hours"]
        n_attack = events_per_day
        n_total = n_normal + n_attack
        sev_blend = (sev_normal * n_normal + 3 * n_attack) / n_total
        offh_blend = (offh_normal * n_normal + 0.4 * n_attack) / n_total
        blended.append({"n_alerts": n_total, "mean_severity": sev_blend, "pct_off_hours": offh_blend})
    return pd.DataFrame(blended)

# baseline "normal" client behaviour to fit the anomaly detector on
normal_days = client_anom[client_anom["client_id"] == cid_test][["n_alerts","mean_severity","pct_off_hours"]]
iso_test = IsolationForest(contamination=0.15, random_state=SEED).fit(normal_days)

evasion_results = []
for spread in [1, 3, 5, 10, 15]:
    attack_days = build_blended_attack_days(n_attack_events=15, spread_days=spread, normal_days_df=normal_days)
    feats = attack_days[["n_alerts","mean_severity","pct_off_hours"]]
    preds = iso_test.predict(feats)
    pct_detected = (preds == -1).mean() * 100
    evasion_results.append({"spread_days": spread, "attack_events_per_day": round(15/spread,2),
                             "pct_days_flagged_anomalous": round(pct_detected,1)})

adversarial_results["test_2_slow_evasive_attack"] = {
    "description": "Same 15-event attack compressed into 1 day vs spread across up to 10 days - "
                    "tests whether per-client daily anomaly detection is evaded by low-and-slow behaviour.",
    "results": evasion_results,
}
print("\n=== Adversarial Test 2: Slow/Evasive Attack ===")
for r in evasion_results:
    print(r)

# --- Test 3: Label poisoning -------------------------------------------------
poison_results = []
for poison_frac in [0.0, 0.05, 0.10, 0.20]:
    y_poisoned = y.copy()
    n_poison = int(len(y_poisoned) * poison_frac)
    if n_poison > 0:
        poison_idx = rng.choice(y_poisoned.index, size=n_poison, replace=False)
        y_poisoned.loc[poison_idx] = 1 - y_poisoned.loc[poison_idx]  # flip label

    X_train, X_test, y_train, y_test = train_test_split(X, y_poisoned, test_size=0.25, random_state=SEED, stratify=y)
    # evaluate against TRUE (unpoisoned) labels on the test set
    _, X_test_true, _, y_test_true = train_test_split(X, y, test_size=0.25, random_state=SEED, stratify=y)
    clf_p = RandomForestClassifier(n_estimators=300, max_depth=10, random_state=SEED, class_weight="balanced")
    clf_p.fit(X_train, y_train)
    y_pred_p = clf_p.predict(X_test_true)
    f1_p = f1_score(y_test_true, y_pred_p)
    poison_results.append({"poisoned_fraction": poison_frac, "f1_vs_true_labels": round(f1_p, 3)})

adversarial_results["test_3_label_poisoning"] = {
    "description": "Flipping an increasing fraction of TP/FP training labels (simulating a compromised "
                    "feedback loop) and evaluating resulting model F1 against TRUE labels.",
    "results": poison_results,
}
print("\n=== Adversarial Test 3: Label Poisoning ===")
for r in poison_results:
    print(r)

with open(f"{OUT}/adversarial_test_results.json", "w") as f:
    json.dump(adversarial_results, f, indent=2, default=str)

# chart: label poisoning degradation
fig, ax = plt.subplots(figsize=(6,4))
pf = [r["poisoned_fraction"] for r in poison_results]
f1s = [r["f1_vs_true_labels"] for r in poison_results]
ax.plot(pf, f1s, marker="o", color="#C00000")
ax.set_xlabel("Fraction of training labels poisoned")
ax.set_ylabel("F1 score (evaluated on true labels)")
ax.set_title("Model Robustness to Label Poisoning")
plt.tight_layout()
plt.savefig(f"{OUT}/adversarial_poisoning_chart.png", dpi=150)
plt.close()

print("\nSaved predictive_risk_forecast.csv, adversarial_test_results.json, adversarial_poisoning_chart.png")
