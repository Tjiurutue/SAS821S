"""
01_generate_data.py
--------------------
Generates synthetic, multi-client MSSP telemetry for T13 (SME Managed Security
Monitoring and Incident Prioritisation).

Produces four data sources into 02_data/raw/:
  - alerts.csv        (~3,000 records) endpoint/network alerts, labelled TP/FP
  - vuln_scans.csv     (~600 records)  vulnerability scan findings
  - auth_logs.csv      (~1,200 records) identity/access (SSO) logs
  - tickets.csv         (200 records)  free-text incident/helpdesk tickets

random_state = 821 for reproducibility (consistent with prior SAS821S work).
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from pathlib import Path
import random

SEED = 821
rng = np.random.default_rng(SEED)
random.seed(SEED)

ROOT = Path(__file__).resolve().parent.parent  # T13_SME_Security/
OUT_DIR = str(ROOT / "02_data" / "raw")
START = datetime(2026, 7, 1)
DAYS = 30

# ---------------------------------------------------------------------------
# 1. Client registry (varying size -> varying "normal" alert volume)
# ---------------------------------------------------------------------------
CLIENTS = [
    {"client_id": "C01", "name": "Kalahari Retail Traders", "size": "small",  "baseline_alerts_per_day": 8},
    {"client_id": "C02", "name": "Nomad Logistics Group",   "size": "medium", "baseline_alerts_per_day": 18},
    {"client_id": "C03", "name": "Windhoek Legal Partners",  "size": "small",  "baseline_alerts_per_day": 6},
    {"client_id": "C04", "name": "Coastal Foods Processing", "size": "medium", "baseline_alerts_per_day": 15},
    {"client_id": "C05", "name": "Etosha Financial Services","size": "large",  "baseline_alerts_per_day": 30},
    {"client_id": "C06", "name": "Swakop Engineering Co.",   "size": "small",  "baseline_alerts_per_day": 7},
    {"client_id": "C07", "name": "Desert Rose Hospitality",  "size": "medium", "baseline_alerts_per_day": 14},
]
clients_df = pd.DataFrame(CLIENTS)
clients_df.to_csv(f"{OUT_DIR}/clients.csv", index=False)

# ---------------------------------------------------------------------------
# 2. Alerts (~3,000) — SIEM-style alert export, labelled TP/FP
# ---------------------------------------------------------------------------
RULE_CATALOGUE = [
    # (rule_id, description, base_severity, mitre_tag, fp_rate, is_attack_family)
    ("R1001", "Multiple failed SSH login attempts",        "medium", "T1110 Brute Force",            0.55, True),
    ("R1002", "Outbound connection to known-bad IP",        "high",   "T1071 Application Layer C2",   0.20, True),
    ("R1003", "Antivirus signature match - generic trojan", "high",   "T1204 User Execution",         0.35, True),
    ("R1004", "Unusual outbound data volume",                "high",   "T1041 Exfiltration Over C2",   0.30, True),
    ("R1005", "PowerShell encoded command executed",         "high",   "T1059 Command Scripting",      0.25, True),
    ("R1006", "New scheduled task created",                  "low",    "T1053 Scheduled Task",         0.70, True),
    ("R1007", "Port scan detected from internal host",       "medium", "T1046 Network Scanning",       0.45, True),
    ("R1008", "Firewall: high volume dropped packets",       "low",    "T1498 Network DoS",            0.80, False),
    ("R1009", "Endpoint: unsigned binary executed",          "medium", "T1204 User Execution",         0.50, True),
    ("R1010", "DNS query to newly-registered domain",        "medium", "T1071 DNS C2",                 0.40, True),
    ("R1011", "Web proxy: repeated 403/blocked requests",    "low",    "T1595 Active Scanning",        0.75, False),
    ("R1012", "Endpoint: ransomware-like mass file rename",  "high",   "T1486 Data Encrypted",         0.10, True),
    ("R1013", "Firewall rule change outside change window",  "low",    "T1562 Impair Defenses",        0.60, False),
    ("R1014", "Suspicious PDF/Office macro opened",          "medium", "T1204 User Execution",         0.45, True),
    ("R1015", "Lateral movement: SMB admin share access",    "high",   "T1021 Remote Services",        0.30, True),
]

SEV_SCORE = {"low": 1, "medium": 2, "high": 3}

def gen_alerts(n_target=3000):
    rows = []
    alert_id = 1
    for c in CLIENTS:
        # scale each client's share of alerts by its baseline
        n_client = int(n_target * (c["baseline_alerts_per_day"] / sum(x["baseline_alerts_per_day"] for x in CLIENTS)))
        for _ in range(n_client):
            rule = RULE_CATALOGUE[rng.integers(0, len(RULE_CATALOGUE))]
            rule_id, desc, sev, mitre, fp_rate, is_attack = rule
            ts = START + timedelta(
                days=int(rng.integers(0, DAYS)),
                hours=int(rng.integers(0, 24)),
                minutes=int(rng.integers(0, 60)),
            )
            # small chance of an off-hours burst (more suspicious)
            off_hours = ts.hour < 6 or ts.hour > 21
            fp_adjust = fp_rate - (0.10 if off_hours else 0)
            is_fp = rng.random() < max(0.05, min(0.95, fp_adjust))
            label = "FP" if is_fp else "TP"

            src_ip = f"10.{rng.integers(0,4)}.{rng.integers(0,255)}.{rng.integers(1,255)}"
            dst_ip = f"{rng.integers(20,210)}.{rng.integers(0,255)}.{rng.integers(0,255)}.{rng.integers(1,255)}"

            rows.append({
                "alert_id": f"A{alert_id:05d}",
                "client_id": c["client_id"],
                "timestamp": ts.isoformat(),
                "rule_id": rule_id,
                "description": desc,
                "severity": sev,
                "severity_score": SEV_SCORE[sev],
                "mitre_tag": mitre,
                "src_ip": src_ip,
                "dst_ip": dst_ip,
                "off_hours": off_hours,
                "label": label,  # TP = genuine incident, FP = false positive (ground truth for supervised model)
            })
            alert_id += 1
    df = pd.DataFrame(rows)
    return df

alerts_df = gen_alerts(3020)
alerts_df.to_csv(f"{OUT_DIR}/alerts.csv", index=False)

# ---------------------------------------------------------------------------
# 3. Vulnerability scan output (~600)
# ---------------------------------------------------------------------------
CVE_POOL = [
    ("CVE-2024-3400", 9.8, "PAN-OS command injection"),
    ("CVE-2023-4863", 8.8, "libwebp heap buffer overflow"),
    ("CVE-2024-21413", 9.8, "Outlook remote code execution"),
    ("CVE-2023-38831", 7.8, "WinRAR code execution"),
    ("CVE-2024-1709", 10.0, "ScreenConnect auth bypass"),
    ("CVE-2022-30190", 7.8, "MSDT (Follina) RCE"),
    ("CVE-2023-23397", 9.8, "Outlook privilege escalation"),
    ("CVE-2021-44228", 10.0, "Log4Shell RCE"),
    ("CVE-2024-27198", 9.8, "TeamCity auth bypass"),
    ("CVE-2023-27997", 9.8, "FortiOS SSL-VPN heap overflow"),
]
ASSET_TYPES = ["workstation", "server", "firewall", "vpn-gateway", "email-server"]

def gen_vuln_scans(n=600):
    rows = []
    for i in range(n):
        c = CLIENTS[rng.integers(0, len(CLIENTS))]
        cve = CVE_POOL[rng.integers(0, len(CVE_POOL))]
        scan_date = START + timedelta(days=int(rng.integers(0, DAYS)))
        rows.append({
            "finding_id": f"V{i+1:05d}",
            "client_id": c["client_id"],
            "asset": f"{c['client_id']}-{ASSET_TYPES[rng.integers(0,len(ASSET_TYPES))]}-{rng.integers(1,20)}",
            "cve_id": cve[0],
            "cvss_score": cve[1],
            "description": cve[2],
            "scan_date": scan_date.date().isoformat(),
            "patched": bool(rng.random() < 0.4),
        })
    return pd.DataFrame(rows)

vuln_df = gen_vuln_scans(600)
vuln_df.to_csv(f"{OUT_DIR}/vuln_scans.csv", index=False)

# ---------------------------------------------------------------------------
# 4. Authentication / SSO logs (~1,200) — identity/access source (C2 requirement)
# ---------------------------------------------------------------------------
FIRST_NAMES = ["Anna","Peter","Maria","John","Grace","Simon","Ruth","David","Linda","Sam",
               "Ndapewa","Tangeni","Karin","Frans","Selma","Erastus","Ester","Josef"]

def gen_auth_logs(n=1200):
    rows = []
    # generate a stable user pool per client
    users_by_client = {c["client_id"]: [f"{c['client_id'].lower()}_{n.lower()}"
                        for n in rng.choice(FIRST_NAMES, size=8, replace=False)] for c in CLIENTS}
    for i in range(n):
        c = CLIENTS[rng.integers(0, len(CLIENTS))]
        user = users_by_client[c["client_id"]][rng.integers(0, len(users_by_client[c["client_id"]]))]
        ts = START + timedelta(days=int(rng.integers(0, DAYS)), hours=int(rng.integers(0, 24)), minutes=int(rng.integers(0,60)))
        off_hours = ts.hour < 6 or ts.hour > 21
        # anomalous login: off-hours + new geography + no MFA -> higher failure/anomaly chance
        anomalous = rng.random() < (0.12 if off_hours else 0.04)
        result = "failed" if (anomalous and rng.random() < 0.6) else "success"
        mfa_used = not anomalous and rng.random() < 0.9
        geo = "unusual_location" if anomalous and rng.random() < 0.5 else "usual_location"
        rows.append({
            "auth_id": f"AU{i+1:05d}",
            "client_id": c["client_id"],
            "timestamp": ts.isoformat(),
            "user": user,
            "result": result,
            "source_ip": f"10.{rng.integers(0,4)}.{rng.integers(0,255)}.{rng.integers(1,255)}" if geo=="usual_location"
                         else f"{rng.integers(20,210)}.{rng.integers(0,255)}.{rng.integers(0,255)}.{rng.integers(1,255)}",
            "geo_flag": geo,
            "mfa_used": mfa_used,
            "off_hours": off_hours,
            "anomalous_ground_truth": anomalous,  # retained for evaluation only, not used as a feature
        })
    return pd.DataFrame(rows)

auth_df = gen_auth_logs(1200)
auth_df.to_csv(f"{OUT_DIR}/auth_logs.csv", index=False)

# ---------------------------------------------------------------------------
# 5. Tickets / incident text (200) — templated with variation for text mining (C8)
# ---------------------------------------------------------------------------
TICKET_TEMPLATES = [
    ("malware", "high", [
        "Endpoint {asset} on {client} flagged by AV for {malware}. User reports machine running slowly and popups appearing.",
        "Multiple files on {asset} were renamed with a strange extension overnight, backups on that share also affected.",
        "{client} helpdesk received a call about a locked screen demanding payment on {asset}, appears to be ransomware.",
    ]),
    ("phishing", "medium", [
        "User at {client} clicked a link in an email claiming to be from their bank and entered their password.",
        "Staff member forwarded a suspicious invoice email asking to update banking details urgently, believed to be phishing.",
        "{client} reports several staff received the same email with a link to a fake login page this morning.",
    ]),
    ("access", "medium", [
        "User account for {client} shows repeated failed logins followed by a success from an unfamiliar location.",
        "Staff member at {client} says they did not request the password reset email they just received.",
        "Admin at {client} noticed a new user account created that nobody on the team recognises.",
    ]),
    ("network", "low", [
        "Firewall at {client} logged a large number of blocked connection attempts from a single external address overnight.",
        "Intermittent connectivity reported at {client}, network team suspects a misconfigured rule after recent change.",
        "Unusual DNS lookups to a domain nobody at {client} recognises were seen in the logs this week.",
    ]),
    ("vulnerability", "medium", [
        "Recent scan at {client} flagged an unpatched VPN gateway, need urgent guidance on remediation timeline.",
        "{client} asked whether the newly disclosed vulnerability in their email server affects their environment.",
    ]),
    ("false_alarm", "low", [
        "Alert triggered by scheduled backup job at {client}, confirmed as expected activity by IT lead.",
        "{client} reports the antivirus alert was a false positive triggered by an internal software update.",
        "Port scan alert at {client} traced back to an authorised vulnerability scan run by the IT team.",
    ]),
]
MALWARE_NAMES = ["Trojan.GenKD", "Win32/Agent", "Ransom.LockCrypt", "Trojan.Emotet"]

def gen_tickets(n=200):
    rows = []
    for i in range(n):
        c = CLIENTS[rng.integers(0, len(CLIENTS))]
        cat, urgency, templates = TICKET_TEMPLATES[rng.integers(0, len(TICKET_TEMPLATES))]
        tmpl = templates[rng.integers(0, len(templates))]
        text = tmpl.format(
            client=c["name"],
            asset=f"WKS-{rng.integers(1,50)}",
            malware=MALWARE_NAMES[rng.integers(0, len(MALWARE_NAMES))],
        )
        ts = START + timedelta(days=int(rng.integers(0, DAYS)), hours=int(rng.integers(0,24)))
        rows.append({
            "ticket_id": f"T{i+1:05d}",
            "client_id": c["client_id"],
            "timestamp": ts.isoformat(),
            "description": text,
            "category_ground_truth": cat,   # retained for evaluation only
            "urgency_ground_truth": urgency,
        })
    return pd.DataFrame(rows)

tickets_df = gen_tickets(200)
tickets_df.to_csv(f"{OUT_DIR}/tickets.csv", index=False)

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
print("Data generation complete.")
print(f"  clients.csv     : {len(clients_df)} rows")
print(f"  alerts.csv      : {len(alerts_df)} rows  (label balance: {alerts_df['label'].value_counts().to_dict()})")
print(f"  vuln_scans.csv  : {len(vuln_df)} rows")
print(f"  auth_logs.csv   : {len(auth_df)} rows  (anomalous: {int(auth_df['anomalous_ground_truth'].sum())})")
print(f"  tickets.csv     : {len(tickets_df)} rows")
total = len(alerts_df) + len(vuln_df) + len(auth_df) + len(tickets_df)
print(f"  TOTAL combined event/transaction records: {total}")
