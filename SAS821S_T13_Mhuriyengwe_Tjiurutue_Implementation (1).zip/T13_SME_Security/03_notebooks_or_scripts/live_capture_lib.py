"""
live_capture_lib.py
---------------------
Shared logic for simulating a real-time event feed and scoring each event
live with the ALREADY-TRAINED models from 03_ml_models.py and
04_text_mining.py (04_models/*.joblib). Nothing here retrains anything —
it demonstrates how a genuine live feed would be captured and categorised
by the same ML pipeline the batch scripts already built and evaluated.

Used by:
  - 08_live_capture_simulator.py (terminal demo, good for a live Milestone 4
    walkthrough: run it and watch events get captured and scored in real time)
  - 07_dashboard_or_prototype/app.py, "Live Capture" tab (in-browser version)

Scope note (worth saying out loud in the presentation): this simulates the
ARRIVAL and SCORING of new events, not a live network feed — the brief's
Charter explicitly scoped out live/intrusive data collection (Section 13).
The unsupervised per-client anomaly detector operates on DAILY aggregates
(see 03_ml_models.py), so it isn't meaningfully re-run per single live event;
what IS live here is the supervised TP/FP risk score and the text-mining
category/urgency classifier, exactly as they would be in production.
"""

import random
import string
from datetime import datetime
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent  # T13_SME_Security/
MODELS_DIR = ROOT / "04_models"
LOG_PATH = ROOT / "08_outputs" / "live_captured_events.csv"

# Canonical column set for the live log. Alerts and tickets produce
# different fields, so every row is reindexed to this full set before being
# written - missing fields simply come out blank rather than misaligning
# columns between rows (a real bug caught in testing: pandas' to_csv(mode="a")
# does NOT align to an existing file's header, it just writes whatever
# columns that row's DataFrame happens to have).
LOG_COLUMNS = [
    "event_type", "captured_at", "event_id", "client_id", "description",
    "rule_id", "severity", "severity_score", "mitre_tag",
    "hour", "dayofweek", "off_hours",
    "tp_probability", "priority_tier",
    "predicted_category", "predicted_urgency",
]

# Same client roster and rule catalogue used to train the models, so every
# value the live generator produces is one the label encoders already know.
CLIENTS = ["C01", "C02", "C03", "C04", "C05", "C06", "C07"]

RULE_CATALOGUE = [
    ("R1001", "Multiple failed SSH login attempts", "medium", "T1110 Brute Force"),
    ("R1002", "Outbound connection to known-bad IP", "high", "T1071 Application Layer C2"),
    ("R1003", "Antivirus signature match - generic trojan", "high", "T1204 User Execution"),
    ("R1004", "Unusual outbound data volume", "high", "T1041 Exfiltration Over C2"),
    ("R1005", "PowerShell encoded command executed", "high", "T1059 Command Scripting"),
    ("R1006", "New scheduled task created", "low", "T1053 Scheduled Task"),
    ("R1007", "Port scan detected from internal host", "medium", "T1046 Network Scanning"),
    ("R1008", "Firewall: high volume dropped packets", "low", "T1498 Network DoS"),
    ("R1009", "Endpoint: unsigned binary executed", "medium", "T1204 User Execution"),
    ("R1010", "DNS query to newly-registered domain", "medium", "T1071 DNS C2"),
    ("R1011", "Web proxy: repeated 403/blocked requests", "low", "T1595 Active Scanning"),
    ("R1012", "Endpoint: ransomware-like mass file rename", "high", "T1486 Data Encrypted"),
    ("R1013", "Firewall rule change outside change window", "low", "T1562 Impair Defenses"),
    ("R1014", "Suspicious PDF/Office macro opened", "medium", "T1204 User Execution"),
    ("R1015", "Lateral movement: SMB admin share access", "high", "T1021 Remote Services"),
]
SEV_SCORE = {"low": 1, "medium": 2, "high": 3}

TICKET_TEMPLATES = [
    "User account for {client} shows repeated failed logins followed by a success from an unfamiliar location.",
    "Endpoint WKS-{n} on {client} flagged by AV for a generic trojan. User reports machine running slowly.",
    "{client} reports several staff received the same email with a link to a fake login page this morning.",
    "Firewall at {client} logged a large number of blocked connection attempts from a single external address.",
    "Recent scan at {client} flagged an unpatched VPN gateway, need urgent guidance on remediation timeline.",
    "Alert triggered by scheduled backup job at {client}, likely a false positive but flagging for review.",
    "Multiple files on WKS-{n} at {client} were renamed with a strange extension overnight.",
    "Staff member at {client} says they did not request the password reset email they just received.",
]


def load_models():
    """Load the already-trained artefacts. Returns None for any file that
    doesn't exist yet (e.g. if 03_ml_models.py / 04_text_mining.py haven't
    been run), so callers can degrade gracefully rather than crash."""
    def _try(name):
        path = MODELS_DIR / name
        return joblib.load(path) if path.exists() else None

    return {
        "clf": _try("tp_fp_classifier.joblib"),
        "encoders": _try("label_encoders.joblib"),
        "vectorizer": _try("tfidf_vectorizer.joblib"),
        "cat_clf": _try("ticket_category_classifier.joblib"),
        "urg_clf": _try("ticket_urgency_classifier.joblib"),
    }


def _safe_encode(encoder, value):
    """Encode a value with a fitted LabelEncoder; falls back to the most
    common training class if a genuinely unseen value ever shows up (won't
    happen with this generator, but this is what a real production system
    would need — worth mentioning as a governance point)."""
    try:
        return int(encoder.transform([value])[0])
    except ValueError:
        return 0


def generate_live_alert(rng):
    """One new synthetic alert, timestamped 'now' (i.e. as if it just fired)."""
    rule_id, description, severity, mitre_tag = RULE_CATALOGUE[rng.integers(0, len(RULE_CATALOGUE))]
    client_id = CLIENTS[rng.integers(0, len(CLIENTS))]
    now = datetime.now()
    return {
        "event_type": "alert",
        "captured_at": now.isoformat(timespec="seconds"),
        "event_id": "LIVE-A" + "".join(random.choices(string.digits, k=5)),
        "client_id": client_id,
        "rule_id": rule_id,
        "description": description,
        "severity": severity,
        "severity_score": SEV_SCORE[severity],
        "mitre_tag": mitre_tag,
        "hour": now.hour,
        "dayofweek": now.weekday(),
        "off_hours": now.hour < 6 or now.hour > 21,
    }


def score_live_alert(event, models):
    """Run the LIVE alert through the already-trained supervised classifier
    - the exact same feature pipeline used in 03_ml_models.py."""
    clf, enc = models["clf"], models["encoders"]
    if clf is None or enc is None:
        event["tp_probability"] = None
        event["priority_tier"] = "UNSCORED (models not found — run 03_ml_models.py first)"
        return event

    features = pd.DataFrame([{
        "severity_score": event["severity_score"],
        "rule_enc": _safe_encode(enc["rule"], event["rule_id"]),
        "mitre_enc": _safe_encode(enc["mitre"], event["mitre_tag"]),
        "client_enc": _safe_encode(enc["client"], event["client_id"]),
        "hour": event["hour"],
        "dayofweek": event["dayofweek"],
        "off_hours_int": int(event["off_hours"]),
    }])
    proba = float(clf.predict_proba(features)[0, 1])
    event["tp_probability"] = round(proba, 3)

    if proba >= 0.75:
        event["priority_tier"] = "🔴 HIGH"
    elif proba >= 0.45:
        event["priority_tier"] = "🟡 MEDIUM"
    else:
        event["priority_tier"] = "🟢 LOW"
    return event


def generate_live_ticket(rng):
    client_id = CLIENTS[rng.integers(0, len(CLIENTS))]
    template = TICKET_TEMPLATES[rng.integers(0, len(TICKET_TEMPLATES))]
    text = template.format(client=client_id, n=rng.integers(1, 50))
    now = datetime.now()
    return {
        "event_type": "ticket",
        "captured_at": now.isoformat(timespec="seconds"),
        "event_id": "LIVE-T" + "".join(random.choices(string.digits, k=5)),
        "client_id": client_id,
        "description": text,
    }


def score_live_ticket(event, models):
    """Run the LIVE ticket text through the already-trained TF-IDF +
    Logistic Regression pipeline from 04_text_mining.py."""
    vec, cat_clf, urg_clf = models["vectorizer"], models["cat_clf"], models["urg_clf"]
    if vec is None or cat_clf is None:
        event["predicted_category"] = "UNSCORED (models not found — run 04_text_mining.py first)"
        event["predicted_urgency"] = None
        return event

    x = vec.transform([event["description"].lower()])
    event["predicted_category"] = cat_clf.predict(x)[0]
    event["predicted_urgency"] = urg_clf.predict(x)[0] if urg_clf is not None else None
    return event


def capture_one_event(rng, models, ticket_probability=0.2):
    """The core 'live capture' step: generate one new event as if it just
    arrived, then immediately score/categorise it with the trained models —
    this is the loop a real MSSP ingestion pipeline would run continuously."""
    if rng.random() < ticket_probability:
        event = generate_live_ticket(rng)
        event = score_live_ticket(event, models)
    else:
        event = generate_live_alert(rng)
        event = score_live_alert(event, models)
    return event


def append_to_log(event):
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    row = pd.DataFrame([event]).reindex(columns=LOG_COLUMNS)
    header = not LOG_PATH.exists()
    row.to_csv(LOG_PATH, mode="a", header=header, index=False)
