"""
02_ingest_and_baseline.py
--------------------------
C3: Data engineering and baseline.
Loads the four raw sources, runs cleaning/quality checks, writes a cleaning
log and data dictionary, and produces per-client descriptive baselines +
visual outputs into 08_outputs/.
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent  # T13_SME_Security/
RAW = str(ROOT / "02_data" / "raw")
PROC = str(ROOT / "02_data" / "processed")
OUT = str(ROOT / "08_outputs")

log = []

def logmsg(msg):
    print(msg)
    log.append(msg)

# ---------------------------------------------------------------------------
# Load
# ---------------------------------------------------------------------------
clients = pd.read_csv(f"{RAW}/clients.csv")
alerts = pd.read_csv(f"{RAW}/alerts.csv", parse_dates=["timestamp"])
vulns = pd.read_csv(f"{RAW}/vuln_scans.csv", parse_dates=["scan_date"])
auth = pd.read_csv(f"{RAW}/auth_logs.csv", parse_dates=["timestamp"])
tickets = pd.read_csv(f"{RAW}/tickets.csv", parse_dates=["timestamp"])

logmsg(f"Loaded alerts={len(alerts)}, vulns={len(vulns)}, auth={len(auth)}, tickets={len(tickets)}")

# ---------------------------------------------------------------------------
# Cleaning / quality checks
# ---------------------------------------------------------------------------
for name, df in [("alerts", alerts), ("vulns", vulns), ("auth", auth), ("tickets", tickets)]:
    n_dupes = df.duplicated().sum()
    n_nulls = df.isna().sum().sum()
    if n_dupes:
        df.drop_duplicates(inplace=True)
        logmsg(f"[{name}] dropped {n_dupes} duplicate rows")
    logmsg(f"[{name}] null cell count: {n_nulls}")
    bad_clients = set(df["client_id"]) - set(clients["client_id"])
    if bad_clients:
        logmsg(f"[{name}] WARNING unknown client_id values: {bad_clients}")
    else:
        logmsg(f"[{name}] client_id referential integrity OK")

# type/range checks
assert alerts["severity_score"].between(1,3).all(), "severity_score out of range"
assert vulns["cvss_score"].between(0,10).all(), "cvss_score out of range"
logmsg("Range checks passed: severity_score in [1,3], cvss_score in [0,10]")

# ---------------------------------------------------------------------------
# Save processed (cleaned) copies
# ---------------------------------------------------------------------------
alerts.to_csv(f"{PROC}/alerts_clean.csv", index=False)
vulns.to_csv(f"{PROC}/vuln_scans_clean.csv", index=False)
auth.to_csv(f"{PROC}/auth_logs_clean.csv", index=False)
tickets.to_csv(f"{PROC}/tickets_clean.csv", index=False)
clients.to_csv(f"{PROC}/clients_clean.csv", index=False)

with open(f"{OUT}/cleaning_log.txt", "w") as f:
    f.write("\n".join(log))

# ---------------------------------------------------------------------------
# Data dictionary
# ---------------------------------------------------------------------------
data_dict = {
    "alerts.csv": {
        "alert_id": "unique alert identifier (string)",
        "client_id": "foreign key to clients.csv",
        "timestamp": "ISO datetime of alert",
        "rule_id": "SIEM detection rule identifier",
        "description": "human-readable rule description",
        "severity": "low / medium / high (analyst-facing label)",
        "severity_score": "numeric encoding of severity (1-3)",
        "mitre_tag": "associated MITRE ATT&CK technique",
        "src_ip": "source IP address",
        "dst_ip": "destination IP address",
        "off_hours": "boolean, alert occurred outside 06:00-21:00",
        "label": "ground truth TP (true positive) / FP (false positive) - training target for supervised model",
    },
    "vuln_scans.csv": {
        "finding_id": "unique finding identifier",
        "client_id": "foreign key to clients.csv",
        "asset": "affected asset identifier",
        "cve_id": "CVE identifier",
        "cvss_score": "CVSS v3 base score (0-10)",
        "description": "vulnerability description",
        "scan_date": "date of scan",
        "patched": "boolean, whether finding has been remediated",
    },
    "auth_logs.csv": {
        "auth_id": "unique authentication event id",
        "client_id": "foreign key to clients.csv",
        "timestamp": "ISO datetime of login attempt",
        "user": "username (pseudonymous, synthetic)",
        "result": "success / failed",
        "source_ip": "source IP of login attempt",
        "geo_flag": "usual_location / unusual_location heuristic",
        "mfa_used": "boolean, whether MFA was used",
        "off_hours": "boolean, outside 06:00-21:00",
        "anomalous_ground_truth": "synthetic ground truth for evaluation only - NOT used as a model feature",
    },
    "tickets.csv": {
        "ticket_id": "unique ticket identifier",
        "client_id": "foreign key to clients.csv",
        "timestamp": "ISO datetime ticket raised",
        "description": "free-text ticket narrative",
        "category_ground_truth": "synthetic category label, used only to evaluate text-mining output",
        "urgency_ground_truth": "synthetic urgency label, used only to evaluate text-mining output",
    },
    "clients.csv": {
        "client_id": "unique client identifier",
        "name": "client organisation name (synthetic)",
        "size": "small / medium / large",
        "baseline_alerts_per_day": "approximate expected daily alert volume used for data generation",
    },
}
with open(f"{OUT}/data_dictionary.json", "w") as f:
    json.dump(data_dict, f, indent=2)
logmsg("Data dictionary written to 08_outputs/data_dictionary.json")

# ---------------------------------------------------------------------------
# Descriptive statistics & per-client visual baselines (C3, C1 descriptive stage)
# ---------------------------------------------------------------------------
alert_counts = alerts.groupby("client_id").size().reindex(clients["client_id"])
fig, ax = plt.subplots(figsize=(7,4))
alert_counts.plot(kind="bar", ax=ax, color="#1F3864")
ax.set_title("Total Alerts per Client (30-day window)")
ax.set_ylabel("Alert count")
plt.tight_layout()
plt.savefig(f"{OUT}/baseline_alerts_per_client.png", dpi=150)
plt.close()

sev_by_client = alerts.groupby(["client_id","severity"]).size().unstack(fill_value=0)
fig, ax = plt.subplots(figsize=(7,4))
sev_by_client.plot(kind="bar", stacked=True, ax=ax, color=["#9DC3E6","#F4B183","#C00000"])
ax.set_title("Alert Severity Mix per Client")
ax.set_ylabel("Alert count")
plt.tight_layout()
plt.savefig(f"{OUT}/baseline_severity_mix.png", dpi=150)
plt.close()

alerts["hour"] = alerts["timestamp"].dt.hour
fig, ax = plt.subplots(figsize=(7,4))
alerts.groupby("hour").size().plot(kind="line", marker="o", ax=ax, color="#1F3864")
ax.set_title("Alert Volume by Hour of Day (all clients)")
ax.set_xlabel("Hour"); ax.set_ylabel("Alert count")
plt.tight_layout()
plt.savefig(f"{OUT}/baseline_hourly_pattern.png", dpi=150)
plt.close()

logmsg("Saved 3 baseline visualisations to 08_outputs/")

desc_stats = alerts.groupby("client_id").agg(
    total_alerts=("alert_id","count"),
    pct_fp=("label", lambda s: round((s=="FP").mean()*100,1)),
    pct_high_sev=("severity", lambda s: round((s=="high").mean()*100,1)),
    pct_off_hours=("off_hours", lambda s: round(s.mean()*100,1)),
).reset_index()
desc_stats.to_csv(f"{OUT}/descriptive_stats_per_client.csv", index=False)
logmsg("Saved descriptive_stats_per_client.csv")
print(desc_stats.to_string(index=False))
