"""
03_ml_models.py
----------------
C4: Machine learning - supervised + unsupervised/anomaly methods.

Supervised: RandomForest classifier predicting TP vs FP on incoming alerts,
            evaluated with confusion matrix, precision, recall, F1.
Unsupervised: IsolationForest anomaly detector run PER CLIENT on alert
            behaviour, producing an anomaly score used later in the risk
            score. Also a simple per-client login-behaviour anomaly check
            on auth_logs.csv (feeds access analytics / Session 7).
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import json
import joblib

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import (confusion_matrix, precision_score, recall_score,
                              f1_score, classification_report, ConfusionMatrixDisplay)

from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent  # T13_SME_Security/
PROC = str(ROOT / "02_data" / "processed")
MODELS = str(ROOT / "04_models")
OUT = str(ROOT / "08_outputs")
SEED = 821

alerts = pd.read_csv(f"{PROC}/alerts_clean.csv", parse_dates=["timestamp"])
auth = pd.read_csv(f"{PROC}/auth_logs_clean.csv", parse_dates=["timestamp"])

# ---------------------------------------------------------------------------
# 1. SUPERVISED: TP/FP alert classifier
# ---------------------------------------------------------------------------
alerts["hour"] = alerts["timestamp"].dt.hour
alerts["dayofweek"] = alerts["timestamp"].dt.dayofweek

le_rule = LabelEncoder()
le_mitre = LabelEncoder()
le_client = LabelEncoder()
alerts["rule_enc"] = le_rule.fit_transform(alerts["rule_id"])
alerts["mitre_enc"] = le_mitre.fit_transform(alerts["mitre_tag"])
alerts["client_enc"] = le_client.fit_transform(alerts["client_id"])
alerts["off_hours_int"] = alerts["off_hours"].astype(int)

FEATURES = ["severity_score", "rule_enc", "mitre_enc", "client_enc", "hour", "dayofweek", "off_hours_int"]
X = alerts[FEATURES]
y = (alerts["label"] == "TP").astype(int)  # 1 = true positive (genuine incident)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=SEED, stratify=y
)

clf = RandomForestClassifier(n_estimators=300, max_depth=10, random_state=SEED, class_weight="balanced")
clf.fit(X_train, y_train)
y_pred = clf.predict(X_test)
y_proba = clf.predict_proba(X_test)[:, 1]

precision = precision_score(y_test, y_pred)
recall = recall_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred)
cm = confusion_matrix(y_test, y_pred)

print("=== Supervised TP/FP Classifier ===")
print(classification_report(y_test, y_pred, target_names=["FP","TP"]))
print("Confusion matrix:\n", cm)

disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=["FP","TP"])
disp.plot(cmap="Blues")
plt.title("Alert Classifier - Confusion Matrix")
plt.tight_layout()
plt.savefig(f"{OUT}/supervised_confusion_matrix.png", dpi=150)
plt.close()

feat_importance = pd.Series(clf.feature_importances_, index=FEATURES).sort_values(ascending=False)
fig, ax = plt.subplots(figsize=(6,4))
feat_importance.plot(kind="barh", ax=ax, color="#1F3864")
ax.set_title("Alert Classifier - Feature Importance")
ax.invert_yaxis()
plt.tight_layout()
plt.savefig(f"{OUT}/supervised_feature_importance.png", dpi=150)
plt.close()

metrics = {
    "precision": round(precision,3), "recall": round(recall,3), "f1": round(f1,3),
    "confusion_matrix": cm.tolist(),
    "n_train": len(X_train), "n_test": len(X_test),
}
with open(f"{OUT}/supervised_metrics.json", "w") as f:
    json.dump(metrics, f, indent=2)

# score ALL alerts (not just test set) for downstream use in the dashboard/simulation
alerts["tp_probability"] = clf.predict_proba(X[FEATURES])[:, 1]
joblib.dump(clf, f"{MODELS}/tp_fp_classifier.joblib")
joblib.dump({"rule": le_rule, "mitre": le_mitre, "client": le_client}, f"{MODELS}/label_encoders.joblib")

# ---------------------------------------------------------------------------
# 2. UNSUPERVISED: per-client behavioural anomaly detection on alerts
# ---------------------------------------------------------------------------
anomaly_scores = []
for cid, grp in alerts.groupby("client_id"):
    # daily alert volume + severity mix as the behavioural signature
    daily = grp.groupby(grp["timestamp"].dt.date).agg(
        n_alerts=("alert_id","count"),
        mean_severity=("severity_score","mean"),
        pct_off_hours=("off_hours_int","mean"),
    ).reset_index().rename(columns={"timestamp":"date"})
    if len(daily) < 5:
        daily["anomaly_score"] = 0
        daily["is_anomalous_day"] = False
    else:
        iso = IsolationForest(contamination=0.15, random_state=SEED)
        feats = daily[["n_alerts","mean_severity","pct_off_hours"]]
        iso.fit(feats)
        # decision_function: higher = more normal. Invert so higher = more anomalous.
        daily["anomaly_score"] = -iso.decision_function(feats)
        daily["is_anomalous_day"] = iso.predict(feats) == -1
    daily["client_id"] = cid
    anomaly_scores.append(daily)

client_anomaly_df = pd.concat(anomaly_scores, ignore_index=True)
client_anomaly_df.to_csv(f"{OUT}/client_daily_anomaly_scores.csv", index=False)

n_anom_days = int(client_anomaly_df["is_anomalous_day"].sum())
print(f"\n=== Unsupervised per-client anomaly detection ===")
print(f"Flagged {n_anom_days} anomalous client-days out of {len(client_anomaly_df)} "
      f"(threshold: IsolationForest contamination=0.15)")

fig, ax = plt.subplots(figsize=(8,4))
for cid, grp in client_anomaly_df.groupby("client_id"):
    grp_sorted = grp.sort_values("date")
    ax.plot(grp_sorted["date"], grp_sorted["anomaly_score"], label=cid, alpha=0.7)
ax.set_title("Per-Client Daily Anomaly Score (higher = more anomalous)")
ax.set_ylabel("Anomaly score")
ax.legend(fontsize=7, ncol=4)
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(f"{OUT}/unsupervised_anomaly_timeline.png", dpi=150)
plt.close()

# ---------------------------------------------------------------------------
# 3. Access analytics (Session 7): login behaviour anomaly per client
# ---------------------------------------------------------------------------
auth["hour"] = auth["timestamp"].dt.hour
auth["off_hours_int"] = auth["off_hours"].astype(int)
auth["failed_int"] = (auth["result"] == "failed").astype(int)
auth["unusual_geo_int"] = (auth["geo_flag"] == "unusual_location").astype(int)
auth["no_mfa_int"] = (~auth["mfa_used"]).astype(int)

auth_feats = auth[["off_hours_int","failed_int","unusual_geo_int","no_mfa_int"]]
iso_auth = IsolationForest(contamination=0.08, random_state=SEED)
iso_auth.fit(auth_feats)
auth["access_anomaly_score"] = -iso_auth.decision_function(auth_feats)
auth["is_anomalous_login"] = iso_auth.predict(auth_feats) == -1

# quick sanity check against synthetic ground truth (evaluation only)
detected = auth["is_anomalous_login"]
truth = auth["anomalous_ground_truth"]
tp = int(((detected) & (truth)).sum())
fn = int(((~detected) & (truth)).sum())
fp = int(((detected) & (~truth)).sum())
recall_auth = tp / (tp + fn) if (tp+fn) else 0
precision_auth = tp / (tp + fp) if (tp+fp) else 0
print(f"\n=== Access anomaly detector (IsolationForest) vs synthetic ground truth ===")
print(f"Recall: {recall_auth:.2f}  Precision: {precision_auth:.2f}  (detected {int(detected.sum())} flags)")

auth.to_csv(f"{OUT}/auth_anomaly_scored.csv", index=False)
joblib.dump(iso_auth, f"{MODELS}/access_anomaly_model.joblib")

alerts.to_csv(f"{PROC}/alerts_scored.csv", index=False)
client_anomaly_df.to_csv(f"{PROC}/client_anomaly_scored.csv", index=False)

print("\nAll models and outputs saved to 04_models/ and 08_outputs/.")
