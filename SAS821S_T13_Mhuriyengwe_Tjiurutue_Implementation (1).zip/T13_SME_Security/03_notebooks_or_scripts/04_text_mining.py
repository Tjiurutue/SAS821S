"""
04_text_mining.py
------------------
C8: Text mining / NLP on unstructured ticket text.

- Preprocessing (lowercasing, tokenising via TF-IDF)
- Supervised category classification (malware / phishing / access / network /
  vulnerability / false_alarm) using ground-truth labels for training+eval
- Supervised urgency scoring (low / medium / high)
- Rule-based entity/indicator extraction (IPs, CVE IDs, asset/host mentions)
"""

import pandas as pd
import numpy as np
import re
import json
import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, f1_score, ConfusionMatrixDisplay, confusion_matrix

from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent  # T13_SME_Security/
PROC = str(ROOT / "02_data" / "processed")
MODELS = str(ROOT / "04_models")
OUT = str(ROOT / "08_outputs")
TEXT_OUT = str(ROOT / "06_text_mining")
SEED = 821

tickets = pd.read_csv(f"{PROC}/tickets_clean.csv")

# ---------------------------------------------------------------------------
# Preprocessing
# ---------------------------------------------------------------------------
def preprocess(text):
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

tickets["clean_text"] = tickets["description"].apply(preprocess)

# ---------------------------------------------------------------------------
# TF-IDF vectorisation (shared across both classification tasks)
# ---------------------------------------------------------------------------
vectorizer = TfidfVectorizer(max_features=300, stop_words="english", ngram_range=(1,2))
X_tfidf = vectorizer.fit_transform(tickets["clean_text"])

# ---------------------------------------------------------------------------
# Category classification
# ---------------------------------------------------------------------------
y_cat = tickets["category_ground_truth"]
X_train, X_test, y_train, y_test, idx_train, idx_test = train_test_split(
    X_tfidf, y_cat, tickets.index, test_size=0.3, random_state=SEED, stratify=y_cat
)
cat_clf = LogisticRegression(max_iter=1000, random_state=SEED)
cat_clf.fit(X_train, y_train)
y_pred_cat = cat_clf.predict(X_test)

print("=== Ticket Category Classification ===")
print(classification_report(y_test, y_pred_cat))
cat_f1 = f1_score(y_test, y_pred_cat, average="macro")

labels_sorted = sorted(y_cat.unique())
cm_cat = confusion_matrix(y_test, y_pred_cat, labels=labels_sorted)
disp = ConfusionMatrixDisplay(confusion_matrix=cm_cat, display_labels=labels_sorted)
fig, ax = plt.subplots(figsize=(7,6))
disp.plot(ax=ax, cmap="Purples", xticks_rotation=45)
plt.title("Ticket Category Classifier - Confusion Matrix")
plt.tight_layout()
plt.savefig(f"{OUT}/text_category_confusion_matrix.png", dpi=150)
plt.close()

# ---------------------------------------------------------------------------
# Urgency classification
# ---------------------------------------------------------------------------
y_urg = tickets["urgency_ground_truth"]
X_train2, X_test2, y_train2, y_test2 = train_test_split(
    X_tfidf, y_urg, test_size=0.3, random_state=SEED, stratify=y_urg
)
urg_clf = LogisticRegression(max_iter=1000, random_state=SEED, class_weight="balanced")
urg_clf.fit(X_train2, y_train2)
y_pred_urg = urg_clf.predict(X_test2)
print("\n=== Ticket Urgency Classification ===")
print(classification_report(y_test2, y_pred_urg))
urg_f1 = f1_score(y_test2, y_pred_urg, average="macro")

# ---------------------------------------------------------------------------
# Score ALL tickets for downstream use (dashboard/intelligence)
# ---------------------------------------------------------------------------
tickets["predicted_category"] = cat_clf.predict(X_tfidf)
tickets["predicted_urgency"] = urg_clf.predict(X_tfidf)
tickets["urgency_score"] = tickets["predicted_urgency"].map({"low":1,"medium":2,"high":3})

# ---------------------------------------------------------------------------
# Rule-based entity / indicator extraction
# ---------------------------------------------------------------------------
IP_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
ASSET_RE = re.compile(r"\bWKS-\d+\b", re.IGNORECASE)
CVE_RE = re.compile(r"\bCVE-\d{4}-\d+\b", re.IGNORECASE)
MALWARE_RE = re.compile(r"\b(Trojan\.\w+|Win32/\w+|Ransom\.\w+)\b")

def extract_entities(text):
    return {
        "ip_addresses": IP_RE.findall(text),
        "assets": ASSET_RE.findall(text),
        "cve_ids": CVE_RE.findall(text),
        "malware_names": MALWARE_RE.findall(text),
    }

tickets["entities"] = tickets["description"].apply(lambda t: json.dumps(extract_entities(t)))
n_with_entities = tickets["entities"].apply(lambda e: any(len(v) > 0 for v in json.loads(e).values())).sum()
print(f"\nEntity extraction: {n_with_entities}/{len(tickets)} tickets contain at least one extracted entity/indicator")

# ---------------------------------------------------------------------------
# Save outputs
# ---------------------------------------------------------------------------
tickets.to_csv(f"{PROC}/tickets_scored.csv", index=False)
joblib.dump(vectorizer, f"{MODELS}/tfidf_vectorizer.joblib")
joblib.dump(cat_clf, f"{MODELS}/ticket_category_classifier.joblib")
joblib.dump(urg_clf, f"{MODELS}/ticket_urgency_classifier.joblib")

text_metrics = {
    "category_macro_f1": round(cat_f1, 3),
    "urgency_macro_f1": round(urg_f1, 3),
    "n_tickets": len(tickets),
    "n_with_extracted_entities": int(n_with_entities),
    "categories": labels_sorted,
}
with open(f"{OUT}/text_mining_metrics.json", "w") as f:
    json.dump(text_metrics, f, indent=2)

# category distribution chart
fig, ax = plt.subplots(figsize=(6,4))
tickets["predicted_category"].value_counts().plot(kind="bar", ax=ax, color="#7030A0")
ax.set_title("Predicted Ticket Category Distribution")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(f"{OUT}/text_category_distribution.png", dpi=150)
plt.close()

print(f"\nSaved scored tickets, models and metrics. Category macro-F1={cat_f1:.2f}, Urgency macro-F1={urg_f1:.2f}")
