"""
tests/test_pipeline.py
------------------------
Test suite for the T13 SME Managed Security Monitoring prototype.
Covers: data-generation integrity (C2/C3), model output sanity (C4),
text-mining output sanity (C8), and the presence of every artefact the
dashboard (C10) depends on.

Run with:  pytest tests/ -v
Assumes the full pipeline (scripts 01-07) has already been run once, since
these are integration/output tests, not unit tests of internal functions.
"""

import pandas as pd
import json
import os
import pytest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent  # T13_SME_Security/
RAW = str(ROOT / "02_data" / "raw")
PROC = str(ROOT / "02_data" / "processed")
OUT = str(ROOT / "08_outputs")
MODELS = str(ROOT / "04_models")


# ---------------------------------------------------------------------------
# C2/C3: Data generation and integrity
# ---------------------------------------------------------------------------
class TestDataIntegrity:

    def test_minimum_combined_record_count(self):
        """Brief Section 5.1: at least 5,000 combined event/transaction records."""
        alerts = pd.read_csv(f"{RAW}/alerts.csv")
        vulns = pd.read_csv(f"{RAW}/vuln_scans.csv")
        auth = pd.read_csv(f"{RAW}/auth_logs.csv")
        tickets = pd.read_csv(f"{RAW}/tickets.csv")
        total = len(alerts) + len(vulns) + len(auth) + len(tickets)
        assert total >= 5000, f"Combined records {total} below the 5,000 minimum"

    def test_minimum_labelled_records_for_supervised(self):
        """Brief Section 5.1: recommended minimum 1,000 labelled records."""
        alerts = pd.read_csv(f"{RAW}/alerts.csv")
        assert len(alerts) >= 1000
        assert set(alerts["label"].unique()) == {"TP", "FP"}

    def test_minimum_text_records(self):
        """Brief Section 5.1: at least 200 unstructured text records."""
        tickets = pd.read_csv(f"{RAW}/tickets.csv")
        assert len(tickets) >= 200

    def test_identity_access_source_present(self):
        """Brief Section 5, C2: at least one identity/access source required."""
        assert os.path.exists(f"{RAW}/auth_logs.csv")
        auth = pd.read_csv(f"{RAW}/auth_logs.csv")
        assert {"user", "result", "mfa_used"}.issubset(auth.columns)

    def test_no_nulls_in_cleaned_data(self):
        for fname in ["alerts_clean.csv", "vuln_scans_clean.csv", "auth_logs_clean.csv", "tickets_clean.csv"]:
            df = pd.read_csv(f"{PROC}/{fname}")
            assert df.isna().sum().sum() == 0, f"{fname} has null values after cleaning"

    def test_referential_integrity_client_ids(self):
        clients = set(pd.read_csv(f"{PROC}/clients_clean.csv")["client_id"])
        for fname in ["alerts_clean.csv", "vuln_scans_clean.csv", "auth_logs_clean.csv", "tickets_clean.csv"]:
            df = pd.read_csv(f"{PROC}/{fname}")
            assert set(df["client_id"]).issubset(clients), f"{fname} has orphaned client_id values"

    def test_severity_score_range(self):
        alerts = pd.read_csv(f"{PROC}/alerts_clean.csv")
        assert alerts["severity_score"].between(1, 3).all()

    def test_cvss_score_range(self):
        vulns = pd.read_csv(f"{PROC}/vuln_scans_clean.csv")
        assert vulns["cvss_score"].between(0, 10).all()

    def test_data_dictionary_covers_all_sources(self):
        with open(f"{OUT}/data_dictionary.json") as f:
            dd = json.load(f)
        for source in ["alerts.csv", "vuln_scans.csv", "auth_logs.csv", "tickets.csv", "clients.csv"]:
            assert source in dd, f"data dictionary missing entry for {source}"


# ---------------------------------------------------------------------------
# C4: Supervised + unsupervised ML sanity
# ---------------------------------------------------------------------------
class TestMLModels:

    def test_supervised_metrics_exist_and_valid_range(self):
        with open(f"{OUT}/supervised_metrics.json") as f:
            m = json.load(f)
        for key in ["precision", "recall", "f1"]:
            assert 0.0 <= m[key] <= 1.0, f"{key}={m[key]} out of [0,1] range"

    def test_supervised_beats_naive_majority_baseline(self):
        """Model should outperform predicting the majority class every time."""
        alerts = pd.read_csv(f"{PROC}/alerts_scored.csv")
        majority_share = alerts["label"].value_counts(normalize=True).max()
        with open(f"{OUT}/supervised_metrics.json") as f:
            m = json.load(f)
        accuracy_est = (m["confusion_matrix"][0][0] + m["confusion_matrix"][1][1]) / \
                       sum(sum(row) for row in m["confusion_matrix"])
        assert accuracy_est > majority_share - 0.02, (
            f"Classifier accuracy {accuracy_est:.3f} does not clear naive baseline {majority_share:.3f}"
        )

    def test_all_alerts_have_tp_probability(self):
        alerts = pd.read_csv(f"{PROC}/alerts_scored.csv")
        assert "tp_probability" in alerts.columns
        assert alerts["tp_probability"].between(0, 1).all()
        assert alerts["tp_probability"].isna().sum() == 0

    def test_unsupervised_anomaly_scores_present(self):
        df = pd.read_csv(f"{PROC}/client_anomaly_scored.csv")
        assert "anomaly_score" in df.columns
        assert "is_anomalous_day" in df.columns
        assert df["is_anomalous_day"].dtype == bool

    def test_access_anomaly_detector_beats_random(self):
        """Sanity check against synthetic ground truth - recall should clearly beat chance."""
        auth = pd.read_csv(f"{OUT}/auth_anomaly_scored.csv")
        base_rate = auth["anomalous_ground_truth"].mean()
        detected_rate = auth["is_anomalous_login"].mean()
        tp = ((auth["is_anomalous_login"]) & (auth["anomalous_ground_truth"])).sum()
        recall = tp / auth["anomalous_ground_truth"].sum()
        assert recall > base_rate, "Detector recall does not clear the base anomaly rate"

    def test_model_files_saved(self):
        for fname in ["tp_fp_classifier.joblib", "access_anomaly_model.joblib", "label_encoders.joblib"]:
            assert os.path.exists(f"{MODELS}/{fname}"), f"missing saved model: {fname}"


# ---------------------------------------------------------------------------
# C8: Text mining sanity
# ---------------------------------------------------------------------------
class TestTextMining:

    def test_text_metrics_present(self):
        with open(f"{OUT}/text_mining_metrics.json") as f:
            m = json.load(f)
        assert "category_macro_f1" in m
        assert "urgency_macro_f1" in m

    def test_all_tickets_scored(self):
        tickets = pd.read_csv(f"{PROC}/tickets_scored.csv")
        assert "predicted_category" in tickets.columns
        assert "predicted_urgency" in tickets.columns
        assert tickets["predicted_category"].isna().sum() == 0

    def test_entity_extraction_ran(self):
        with open(f"{OUT}/text_mining_metrics.json") as f:
            m = json.load(f)
        assert m["n_with_extracted_entities"] >= 0  # ran without error; count is data-dependent


# ---------------------------------------------------------------------------
# C5/C6: Investigation and intelligence outputs
# ---------------------------------------------------------------------------
class TestInvestigationIntelligence:

    def test_operational_queue_ranked(self):
        q = pd.read_csv(f"{OUT}/operational_priority_queue.csv")
        assert "priority_rank" in q.columns
        assert q["priority_rank"].is_monotonic_increasing
        assert (q["tp_probability"].diff().dropna() <= 1e-9).all(), "queue not sorted by descending risk"

    def test_executive_digest_has_all_clients(self):
        digest = pd.read_csv(f"{OUT}/executive_risk_digest.csv")
        clients = pd.read_csv(f"{PROC}/clients_clean.csv")
        assert set(digest["client_id"]) == set(clients["client_id"])

    def test_risk_tiers_valid(self):
        digest = pd.read_csv(f"{OUT}/executive_risk_digest.csv")
        assert set(digest["risk_tier"].unique()).issubset({"Low", "Medium", "High"})


# ---------------------------------------------------------------------------
# C7: Simulation sanity
# ---------------------------------------------------------------------------
class TestSimulation:

    def test_simulation_ran_minimum_iterations(self):
        with open(f"{OUT}/simulation_assumptions.json") as f:
            a = json.load(f)
        assert a["n_iterations"] >= 1000, "brief requires >=1,000 Monte Carlo iterations"

    def test_three_strategies_compared(self):
        summary = pd.read_csv(f"{OUT}/simulation_summary.csv")
        assert len(summary) == 3
        assert set(summary["strategy"]) == {"manual_fifo", "risk_scored", "risk_scored_suppress"}

    def test_risk_scored_beats_manual_fifo(self):
        """Core hypothesis check: risk-scored triage should review more TPs than manual FIFO."""
        summary = pd.read_csv(f"{OUT}/simulation_summary.csv").set_index("strategy")
        assert summary.loc["risk_scored", "mean_pct_tp_reviewed"] >= summary.loc["manual_fifo", "mean_pct_tp_reviewed"]


# ---------------------------------------------------------------------------
# C9: Predictive and adversarial sanity
# ---------------------------------------------------------------------------
class TestPredictiveAdversarial:

    def test_forecast_covers_all_clients(self):
        forecast = pd.read_csv(f"{OUT}/predictive_risk_forecast.csv")
        clients = pd.read_csv(f"{PROC}/clients_clean.csv")
        assert set(forecast["client_id"]) == set(clients["client_id"])

    def test_at_least_three_adversarial_tests(self):
        with open(f"{OUT}/adversarial_test_results.json") as f:
            adv = json.load(f)
        test_keys = [k for k in adv.keys() if k.startswith("test_")]
        assert len(test_keys) >= 3, "brief requires at least 3 adversarial/robustness tests"

    def test_poisoning_degrades_monotonically_or_flat(self):
        """Sanity check: heavier label poisoning should not IMPROVE model F1."""
        with open(f"{OUT}/adversarial_test_results.json") as f:
            adv = json.load(f)
        results = adv["test_3_label_poisoning"]["results"]
        f1_clean = results[0]["f1_vs_true_labels"]
        f1_heaviest = results[-1]["f1_vs_true_labels"]
        assert f1_heaviest <= f1_clean + 0.02, "F1 should not meaningfully improve under heavier poisoning"


# ---------------------------------------------------------------------------
# C10: Dashboard dependency check
# ---------------------------------------------------------------------------
class TestDashboardDependencies:

    REQUIRED_FILES = [
        f"{PROC}/alerts_scored.csv", f"{PROC}/tickets_scored.csv", f"{PROC}/clients_clean.csv",
        f"{OUT}/executive_risk_digest.csv", f"{OUT}/incident_timeline.csv",
        f"{OUT}/predictive_risk_forecast.csv", f"{OUT}/simulation_summary.csv",
        f"{OUT}/simulation_sensitivity.csv", f"{OUT}/adversarial_test_results.json",
        f"{OUT}/supervised_metrics.json", f"{OUT}/text_mining_metrics.json",
    ]

    @pytest.mark.parametrize("filepath", REQUIRED_FILES)
    def test_dashboard_dependency_exists(self, filepath):
        assert os.path.exists(filepath), f"dashboard dependency missing: {filepath}"

    def test_dashboard_app_syntax_valid(self):
        import py_compile
        app_path = str(ROOT / "07_dashboard_or_prototype" / "app.py")
        py_compile.compile(app_path, doraise=True)


# ---------------------------------------------------------------------------
# Live capture simulation (added feature: real-time event scoring demo)
# ---------------------------------------------------------------------------
class TestLiveCapture:

    def test_live_capture_produces_rectangular_log(self):
        """Regression test for a real bug caught during development: alert and
        ticket events have different fields, so appending them naively can
        misalign CSV columns. Confirms the fix (LOG_COLUMNS reindex) holds."""
        import sys
        sys.path.insert(0, str(ROOT / "03_notebooks_or_scripts"))
        from live_capture_lib import capture_one_event, load_models, LOG_COLUMNS
        import numpy as np

        models = load_models()
        rng = np.random.default_rng(1)
        events = [capture_one_event(rng, models) for _ in range(10)]
        df = pd.DataFrame(events).reindex(columns=LOG_COLUMNS)

        assert list(df.columns) == LOG_COLUMNS
        assert df["client_id"].isna().sum() == 0
        assert set(df["event_type"].unique()).issubset({"alert", "ticket"})

    def test_live_alert_scoring_uses_trained_model(self):
        import sys
        sys.path.insert(0, str(ROOT / "03_notebooks_or_scripts"))
        from live_capture_lib import generate_live_alert, score_live_alert, load_models
        import numpy as np

        models = load_models()
        if models["clf"] is None:
            pytest.skip("no trained classifier available")
        rng = np.random.default_rng(2)
        event = score_live_alert(generate_live_alert(rng), models)
        assert 0.0 <= event["tp_probability"] <= 1.0
        assert event["priority_tier"] in {"🔴 HIGH", "🟡 MEDIUM", "🟢 LOW"}
